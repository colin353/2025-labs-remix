<h2>Log in here.</h2>

<p>Log in here to access the internal 2025 site. For employees only.</p>

<form method=post action=<?=base_url()?>welcome/authenticate >
<p><label>Username</label><input type=text name=username /></p>
<p><label>Password</label><input type=password name=password /></p>

<input type=submit value="Log in" />
</form>

